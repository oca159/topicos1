package com.actionbarsherlock.view;

public abstract interface CollapsibleActionView
{
  public abstract void onActionViewCollapsed();

  public abstract void onActionViewExpanded();
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.actionbarsherlock.view.CollapsibleActionView
 * JD-Core Version:    0.6.0
 */