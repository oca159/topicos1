package com.actionbarsherlock;

public final class BuildConfig
{
  public static final boolean DEBUG;
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.actionbarsherlock.BuildConfig
 * JD-Core Version:    0.6.0
 */