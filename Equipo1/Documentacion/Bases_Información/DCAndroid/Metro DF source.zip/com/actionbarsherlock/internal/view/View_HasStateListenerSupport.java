package com.actionbarsherlock.internal.view;

public abstract interface View_HasStateListenerSupport
{
  public abstract void addOnAttachStateChangeListener(View_OnAttachStateChangeListener paramView_OnAttachStateChangeListener);

  public abstract void removeOnAttachStateChangeListener(View_OnAttachStateChangeListener paramView_OnAttachStateChangeListener);
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.actionbarsherlock.internal.view.View_HasStateListenerSupport
 * JD-Core Version:    0.6.0
 */