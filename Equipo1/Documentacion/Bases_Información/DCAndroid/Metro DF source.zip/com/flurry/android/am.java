package com.flurry.android;

final class am extends ak
{
  String a;
  String b;
  int c;
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.flurry.android.am
 * JD-Core Version:    0.6.0
 */