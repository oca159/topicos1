package com.flurry.android;

public abstract interface AppCircleCallback
{
  public abstract void onAdsUpdated(CallbackEvent paramCallbackEvent);

  public abstract void onMarketAppLaunchError(CallbackEvent paramCallbackEvent);
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.flurry.android.AppCircleCallback
 * JD-Core Version:    0.6.0
 */