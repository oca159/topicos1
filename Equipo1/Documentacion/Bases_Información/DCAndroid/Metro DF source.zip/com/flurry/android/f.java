package com.flurry.android;

final class f
{
  final byte a;
  final long b;

  f(byte paramByte, long paramLong)
  {
    this.a = paramByte;
    this.b = paramLong;
  }

  public final String toString()
  {
    return "[" + this.b + "] " + this.a;
  }
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.flurry.android.f
 * JD-Core Version:    0.6.0
 */