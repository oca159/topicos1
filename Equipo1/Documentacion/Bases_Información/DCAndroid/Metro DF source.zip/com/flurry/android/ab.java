package com.flurry.android;

final class ab
{
  int a = FlurryAgent.g();
  long b;
  String c;
  String d;
  String e;
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.flurry.android.ab
 * JD-Core Version:    0.6.0
 */