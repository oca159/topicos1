package com.flurry.android;

import android.text.SpannedString;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.widget.TextView;

final class ad
  implements View.OnFocusChangeListener
{
  ad(ac paramac, TextView paramTextView)
  {
  }

  public final void onFocusChange(View paramView, boolean paramBoolean)
  {
    if (paramBoolean);
    for (SpannedString localSpannedString = ac.a(this.b); ; localSpannedString = ac.b(this.b))
    {
      this.a.setText(localSpannedString);
      return;
    }
  }
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.flurry.android.ad
 * JD-Core Version:    0.6.0
 */