package com.flurry.android;

final class g
{
  int a;

  private g(byte paramByte)
  {
  }
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.flurry.android.g
 * JD-Core Version:    0.6.0
 */