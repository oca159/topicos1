package com.flurry.android;

import java.util.List;

final class y
{
  String a;
  List b;
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.flurry.android.y
 * JD-Core Version:    0.6.0
 */