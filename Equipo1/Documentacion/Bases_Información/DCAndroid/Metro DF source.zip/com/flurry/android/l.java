package com.flurry.android;

final class l
  implements Runnable
{
  l(b paramb)
  {
  }

  public final void run()
  {
    FlurryAgent.b(this.a.b, this.a.a);
  }
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.flurry.android.l
 * JD-Core Version:    0.6.0
 */