package com.flurry.android;

import android.os.Handler;

final class a
{
  String a;
  long b;
  String c;
  String d;
  Handler e;
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.flurry.android.a
 * JD-Core Version:    0.6.0
 */