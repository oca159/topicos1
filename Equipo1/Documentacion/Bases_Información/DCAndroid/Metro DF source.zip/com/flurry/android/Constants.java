package com.flurry.android;

public abstract interface Constants
{
  public static final byte FEMALE = 0;
  public static final byte MALE = 1;
  public static final int MODE_LANDSCAPE = 2;
  public static final int MODE_PORTRAIT = 1;
  public static final byte UNKNOWN = -1;
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.flurry.android.Constants
 * JD-Core Version:    0.6.0
 */