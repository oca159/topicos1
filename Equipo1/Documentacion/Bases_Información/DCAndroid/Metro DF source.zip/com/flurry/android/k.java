package com.flurry.android;

final class k
  implements Runnable
{
  k(ah paramah)
  {
  }

  public final void run()
  {
    ah.a(this.a);
  }
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.flurry.android.k
 * JD-Core Version:    0.6.0
 */