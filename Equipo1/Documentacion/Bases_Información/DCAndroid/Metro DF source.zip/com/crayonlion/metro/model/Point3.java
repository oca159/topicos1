package com.crayonlion.metro.model;

public class Point3
{
  public int x;
  public int y;
  public int z;

  public Point3(int paramInt1, int paramInt2, int paramInt3)
  {
    this.x = paramInt1;
    this.y = paramInt2;
    this.z = paramInt3;
  }
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.crayonlion.metro.model.Point3
 * JD-Core Version:    0.6.0
 */