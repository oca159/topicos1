package com.crayonlion.metro.model;

public class Tupla<T>
{
  public T a;
  public T b;

  public Tupla()
  {
  }

  public Tupla(T paramT1, T paramT2)
  {
    this.a = paramT1;
    this.b = paramT2;
  }
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.crayonlion.metro.model.Tupla
 * JD-Core Version:    0.6.0
 */