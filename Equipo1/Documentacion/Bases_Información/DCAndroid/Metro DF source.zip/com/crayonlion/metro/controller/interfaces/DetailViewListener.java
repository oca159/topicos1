package com.crayonlion.metro.controller.interfaces;

public abstract interface DetailViewListener
{
  public abstract void onDetailViewDisplay();
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.crayonlion.metro.controller.interfaces.DetailViewListener
 * JD-Core Version:    0.6.0
 */