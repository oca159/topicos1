package com.crayonlion.metro;

import com.actionbarsherlock.app.SherlockFragment;

public abstract class EasyFragment extends SherlockFragment
{
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.crayonlion.metro.EasyFragment
 * JD-Core Version:    0.6.0
 */