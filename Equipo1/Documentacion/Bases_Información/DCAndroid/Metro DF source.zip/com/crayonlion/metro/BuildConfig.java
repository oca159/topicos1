package com.crayonlion.metro;

public final class BuildConfig
{
  public static final boolean DEBUG;
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.crayonlion.metro.BuildConfig
 * JD-Core Version:    0.6.0
 */