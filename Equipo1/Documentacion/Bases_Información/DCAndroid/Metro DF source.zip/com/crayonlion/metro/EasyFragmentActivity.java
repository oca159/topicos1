package com.crayonlion.metro;

import android.os.Bundle;
import com.actionbarsherlock.app.SherlockFragmentActivity;

public abstract class EasyFragmentActivity extends SherlockFragmentActivity
{
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
  }
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     com.crayonlion.metro.EasyFragmentActivity
 * JD-Core Version:    0.6.0
 */