package android.support.v4.content.pm;

public class ActivityInfoCompat
{
  public static final int CONFIG_UI_MODE = 512;
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.content.pm.ActivityInfoCompat
 * JD-Core Version:    0.6.0
 */