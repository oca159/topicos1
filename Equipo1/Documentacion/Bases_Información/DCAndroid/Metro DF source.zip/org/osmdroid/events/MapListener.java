package org.osmdroid.events;

public abstract interface MapListener
{
  public abstract boolean onScroll(ScrollEvent paramScrollEvent);

  public abstract boolean onZoom(ZoomEvent paramZoomEvent);
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     org.osmdroid.events.MapListener
 * JD-Core Version:    0.6.0
 */