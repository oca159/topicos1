package org.osmdroid.events;

public abstract interface MapEvent
{
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     org.osmdroid.events.MapEvent
 * JD-Core Version:    0.6.0
 */