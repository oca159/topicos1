package org.osmdroid.views.util.constants;

public abstract interface OverlayConstants
{
  public static final boolean DEBUGMODE = false;
  public static final int DEFAULT_ZOOMLEVEL_MINIMAP_DIFFERENCE = 3;
  public static final int NOT_SET = -2147483648;
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     org.osmdroid.views.util.constants.OverlayConstants
 * JD-Core Version:    0.6.0
 */