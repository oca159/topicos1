package org.osmdroid.api;

public abstract interface IGeoPoint
{
  public abstract int getLatitudeE6();

  public abstract int getLongitudeE6();
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     org.osmdroid.api.IGeoPoint
 * JD-Core Version:    0.6.0
 */