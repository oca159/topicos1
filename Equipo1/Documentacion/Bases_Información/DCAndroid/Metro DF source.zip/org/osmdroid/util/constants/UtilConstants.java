package org.osmdroid.util.constants;

public abstract interface UtilConstants
{
  public static final long GPS_WAIT_TIME = 20000L;
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     org.osmdroid.util.constants.UtilConstants
 * JD-Core Version:    0.6.0
 */