package org.slf4j;

public abstract interface ILoggerFactory
{
  public abstract Logger getLogger(String paramString);
}

/* Location:           C:\DCAndroid\classes-dex2jar.jar
 * Qualified Name:     org.slf4j.ILoggerFactory
 * JD-Core Version:    0.6.0
 */